package co.edu.unipiloto.labappbars;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void btn_User(View view){
        //Toast.makeText(this,"aaaaaaaaaaaaa siuuuuu",Toast.LENGTH_LONG);
        //startActivity(new Intent(this, Registro.class));

        Intent intent = new Intent(this, Publicar.class);
        startActivity(intent);
        finish();
    }

    public void btn_Reciclador(View view){
        //Toast.makeText(this,"aaaaaaaaaaaaa siuuuuu",Toast.LENGTH_LONG);
        //startActivity(new Intent(this, Registro.class));

        Intent intent = new Intent(this, Aplicar.class);
        startActivity(intent);
        finish();
    }
}